
package hotel_252;


public abstract class ExtraServicesDecorator extends Room {
    Room room;
    public abstract int cost();
}

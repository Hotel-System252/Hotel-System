/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel_252;


/**
 *
 * @author Nero
 */
public abstract class Room {
    
    private int price=0;
    public abstract int cost();

}
